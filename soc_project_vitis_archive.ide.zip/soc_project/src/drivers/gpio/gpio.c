#include "gpio.h"
#include "xparameters.h"
#include "xgpio.h"

#include "../../param_config.h"

XGpio Gpio_0;
XGpio Gpio_1;

// Reads from GPIO0 and GPIO1
uint32_t gpio_read(uint32_t pin) {

	uint32_t value = 0;

	if(pin >= SW_0 && pin <= SW_1) {

		value = XGpio_DiscreteRead(&Gpio_0, 1);		// Read from channel 1

		if(pin == SW_0) return value & 0x1;
		else return (value >> 1) & 0x1;

	} else if(pin >= BTN_0 && pin <= BTN_3) {

		value = XGpio_DiscreteRead(&Gpio_0, 2);		// Read from channel 2

		//printf("%d\n", value);

		if(pin == BTN_0) return value & 0x1;
		else if(pin == BTN_1) return (value >> 1) & 0x1;
		else if(pin == BTN_2) return (value >> 2) & 0x1;
		else return (value >> 3) & 0x1;

	} else if(pin >= LED_0 && pin <= LED_3) {

		value = XGpio_DiscreteRead(&Gpio_1, 1);		// Read from channel 1

		if(pin == LED_0) return value & 0x1;
		else if(pin == LED_1) return (value >> 1) & 0x1;
		else if(pin == LED_2) return (value >> 2) & 0x1;
		else return (value >> 3) & 0x1;

	} else if(pin >= RGB_0 && pin <= RGB_2) {

		value = XGpio_DiscreteRead(&Gpio_1, 2);		// Read from channel 2

		if(pin == RGB_0) return value & 0x1;
		else if(pin == RGB_1) return (value >> 1) & 0x1;
		else return (value >> 2) & 0x1;

	} else return value;

}

// Only writes to GPIO 1
void gpio_write(uint32_t pin, uint32_t value) {

	uint32_t reg_value = 0;

	if(pin >= LED_0 && pin <= LED_3) {

		reg_value = XGpio_DiscreteRead(&Gpio_1, 1);		// Read from channel 1

		if(value == 0) {

			if(pin == LED_0) reg_value &= ~0x1;
			else if(pin == LED_1) reg_value &= ~0x2;
			else if(pin == LED_2) reg_value &= ~0x4;
			else reg_value &= ~0x8;

		} else {

			if(pin == LED_0) reg_value |= 0x1;
			else if(pin == LED_1) reg_value |= 0x2;
			else if(pin == LED_2) reg_value |= 0x4;
			else reg_value |= 0x8;

		}

		XGpio_DiscreteWrite(&Gpio_1, 1, reg_value);		// Write to channel 1

	} else if(pin >= RGB_0 && pin <= RGB_2) {

		reg_value = XGpio_DiscreteRead(&Gpio_1, 2);		// Read from channel 2

		if(value == 0) {

			if(pin == RGB_0) reg_value &= ~0x1;
			else if(pin == RGB_1) reg_value &= ~0x2;
			else reg_value &= ~0x4;

		} else {

			if(pin == RGB_0) reg_value |= 0x1;
			else if(pin == RGB_1) reg_value |= 0x2;
			else reg_value |= 0x4;

		}

		XGpio_DiscreteWrite(&Gpio_1, 2, reg_value);		// Write to channel 2

	}

	return;

}

// Initialize driver
int gpio_init() {

	int Status;
	XGpio_Config *Gpio_Config_0;
	XGpio_Config *Gpio_Config_1;

	Gpio_Config_0 = XGpio_LookupConfig(XPAR_AXI_GPIO_0_DEVICE_ID);
	if(Gpio_Config_0 == NULL) return XST_FAILURE;

	Gpio_Config_1 = XGpio_LookupConfig(XPAR_AXI_GPIO_1_DEVICE_ID);
	if(Gpio_Config_1 == NULL) return XST_FAILURE;

	Status = XGpio_CfgInitialize(&Gpio_0, Gpio_Config_0, Gpio_Config_0->BaseAddress);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	Status = XGpio_CfgInitialize(&Gpio_1, Gpio_Config_1, Gpio_Config_1->BaseAddress);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// DATA DIRECTION ALREADY SET IN VIVADO BUT STILL JUST IN CASE
	XGpio_SetDataDirection(&Gpio_0, 1, 0xFFFFFFFF);
	XGpio_SetDataDirection(&Gpio_0, 2, 0xFFFFFFFF);
	XGpio_SetDataDirection(&Gpio_1, 1, 0x0);
	XGpio_SetDataDirection(&Gpio_1, 2, 0x0);

	return XST_SUCCESS;

}
