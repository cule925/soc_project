#ifndef GPIO_INIT_H
#define GPIO_INIT_H

#include <stdint.h>

// Definitions for switches, pushbuttons, LEDs and RGB LEDs
#define SW_0			0
#define SW_1			1

#define BTN_0			2
#define BTN_1			3
#define BTN_2			4
#define BTN_3			5

#define LED_0			6
#define LED_1			7
#define LED_2			8
#define LED_3			9

#define RGB_0			10
#define RGB_1			11
#define RGB_2			12

// Driver interface
int gpio_init();
uint32_t gpio_read(uint32_t pin);
void gpio_write(uint32_t pin, uint32_t value);

#endif
