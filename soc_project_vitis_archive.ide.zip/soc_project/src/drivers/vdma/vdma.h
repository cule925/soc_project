#ifndef VDMA_INIT_H
#define VDMA_INIT_H

#include <stdint.h>

// Register addresses
#define PARK_PTR_REG			0x28
#define VDMA_VERSION			0x2C
#define S2MM_VDMACR				0x30
#define S2MM_VDMASR				0x34
#define S2MM_VDMA_IRQ_MASK		0x3C
#define S2MM_REG_INDEX			0x44
#define S2MM_VSIZE				0xA0
#define S2MM_HSIZE				0xA4
#define S2MM_FRMDLY_STRIDE		0xA8

#define FRM_BUF_1_ADDR			0xAC
#define FRM_BUF_2_ADDR			0xB0
#define FRM_BUF_3_ADDR			0xB4

// Driver interface
int vdma_init();
int frame_buffer_is_busy(uint32_t buffer_index);

#endif
