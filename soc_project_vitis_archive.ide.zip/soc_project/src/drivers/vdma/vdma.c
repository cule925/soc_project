#include "vdma.h"
#include "xparameters.h"
#include "xaxivdma.h"
#include "xil_printf.h"

#include "../../param_config.h"

XAxiVdma Axi_Vdma;

// Added
XAxiVdma_DmaSetup Setup_Dma;

// Check if the frame is being written to
int frame_buffer_is_busy(uint32_t buffer_index) {

	uint32_t busy_buffer_index;
	busy_buffer_index = (XAxiVdma_ReadReg(Axi_Vdma.BaseAddr, PARK_PTR_REG) & XAXIVDMA_PARKPTR_WRTSTR_MASK) >> 24;

	// Clear all errors
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VDMASR, XAXIVDMA_SR_ERR_ALL_MASK);

	if(busy_buffer_index == buffer_index) return XST_FAILURE;
	else return XST_SUCCESS;

}

// Configure VDMA
int vdma_config() {

	uint32_t stopped = 1;
	uint32_t halted = 0;

	// Reset VDMA
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VDMACR, XAXIVDMA_CR_RESET_MASK);

	// Check if VDMA has reset itself
	while (XAxiVdma_ReadReg(Axi_Vdma.BaseAddr, S2MM_VDMACR) & XAXIVDMA_CR_RESET_MASK);

	// Unmask interrupts
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VDMA_IRQ_MASK, 0xF);

	// Wait for VDMA to be in stop or halt
	while(1) {

		// 0 if true
		stopped = XAxiVdma_ReadReg(Axi_Vdma.BaseAddr, S2MM_VDMACR) & XAXIVDMA_CR_RUNSTOP_MASK;

		// 1 if true
		halted = XAxiVdma_ReadReg(Axi_Vdma.BaseAddr, S2MM_VDMASR) & XAXIVDMA_SR_HALTED_MASK;

		if(!stopped || halted) break;

	}

	// Start up buffers0
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VDMACR,
	                  XAXIVDMA_CR_RUNSTOP_MASK |
					  /*XAXIVDMA_CR_SYNC_EN_MASK |
					  XAXIVDMA_CR_GENLCK_SRC_MASK |*/
					  XAXIVDMA_CR_TAIL_EN_MASK);


	// Set FrameBuffer addresses
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, FRM_BUF_1_ADDR, (UINTPTR)FRAME_BUFFER_1);
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, FRM_BUF_2_ADDR, (UINTPTR)FRAME_BUFFER_2);
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, FRM_BUF_3_ADDR, (UINTPTR)FRAME_BUFFER_3);

	// Write 0 to park pointer register
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, PARK_PTR_REG, 0x0);

	// Frame delay and stride
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_FRMDLY_STRIDE, WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE));

	// Write horizontal size
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_HSIZE, WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE));

	// Write vertical size
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VSIZE, HEIGHT);

	// Clear all errors
	XAxiVdma_WriteReg(Axi_Vdma.BaseAddr, S2MM_VDMASR, XAXIVDMA_SR_ERR_ALL_MASK);

	return XST_SUCCESS;

}

// Initialize driver
int vdma_init() {

	int Status;
	XAxiVdma_Config *Axi_Vdma_Config;

	Axi_Vdma_Config = XAxiVdma_LookupConfig(XPAR_AXI_VDMA_0_DEVICE_ID);
	if(Axi_Vdma_Config == NULL) return XST_FAILURE;

	Status = XAxiVdma_CfgInitialize(&Axi_Vdma, Axi_Vdma_Config, Axi_Vdma_Config->BaseAddress);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	Status = vdma_config();
	if(Status != XST_SUCCESS) return XST_FAILURE;

	return XST_SUCCESS;

}
