#include "udp_client.h"

#include "lwipopts.h"
#include "lwip/ip_addr.h"
#include "lwip/err.h"
#include "lwip/udp.h"
#include "lwip/inet.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "errno.h"
#include <sleep.h>
#include <string.h>
#include "xil_printf.h"
#include "xlwipconfig.h"

#include "../../param_config.h"

extern struct netif server_netif;
static struct perf_stats client;
static char send_buf[UDP_SEND_BUFSIZE] = {0};
static struct sockaddr_in addr;
static int udp_socket;

/* used as indices into kLabel[] */
enum {
	KCONV_UNIT,
	KCONV_KILO,
	KCONV_MEGA,
	KCONV_GIGA,
};

/* labels for formats [KMG] */
const char kLabel[] =
{
	' ',
	'K',
	'M',
	'G'
};

/* used as type of print */
enum measure_t {
	BYTES,
	SPEED
};

/* Report Type */
enum report_type {
	/* The Intermediate report */
	INTER_REPORT,
	/* The client side test is done */
	UDP_DONE_CLIENT,
	/* Remote side aborted the test */
	UDP_ABORTED_REMOTE
};

struct interim_report {
	u64_t start_time;
	u64_t last_report_time;
	u32_t total_bytes;
};

struct perf_stats {
	u8_t client_id;
	u64_t start_time;
	u64_t total_bytes;
	u64_t cnt_datagrams;
	struct interim_report i_report;
};

#define FINISH	1
/* Report interval time in ms */
#define REPORT_INTERVAL_TIME (INTERIM_REPORT_INTERVAL * 1000)

void print_app_header() {

	xil_printf("UDP client connecting to %s on port %d\n", UDP_SERVER_IP_ADDRESS, UDP_CONN_PORT);

}

static void print_udp_conn_stats(void) {

	xil_printf("[%3d] local %s port %d connected with ", client.client_id, inet_ntoa(server_netif.ip_addr), UDP_CONN_PORT);
	xil_printf("%s port %d\n", UDP_SERVER_IP_ADDRESS,	UDP_CONN_PORT);
	xil_printf("[ ID] Interval\t\tTransfer   Bandwidth\n");

}

static void stats_buffer(char* outString, double data, enum measure_t type) {

	int conv = KCONV_UNIT;
	const char *format;
	double unit = 1024.0;

	if (type == SPEED)
		unit = 1000.0;

	while (data >= unit && conv <= KCONV_GIGA) {
		data /= unit;
		conv++;
	}

	/* Fit data in 4 places */
	if (data < 9.995) { /* 9.995 rounded to 10.0 */
		format = "%4.2f %c"; /* #.## */
	} else if (data < 99.95) { /* 99.95 rounded to 100 */
		format = "%4.1f %c"; /* ##.# */
	} else {
		format = "%4.0f %c"; /* #### */
	}

	sprintf(outString, format, data, kLabel[conv]);

}


/* The report function of a UDP client session */
static void udp_conn_report(u64_t diff, enum report_type report_type) {

	u64_t total_len;
	double duration, bandwidth = 0;
	char data[16], perf[16], time[64];

	if (report_type == INTER_REPORT) {
		total_len = client.i_report.total_bytes;
	} else {
		client.i_report.last_report_time = 0;
		total_len = client.total_bytes;
	}

	duration = diff / 1000.0; /* secs */
	if (duration) bandwidth = (total_len / duration) * 8.0;

	stats_buffer(data, total_len, BYTES);
	stats_buffer(perf, bandwidth, SPEED);

	sprintf(time, "%4.1f-%4.1f sec", (double)client.i_report.last_report_time, (double)(client.i_report.last_report_time + duration));
	xil_printf("[%3d] %s  %sBytes  %sbits/sec\n", client.client_id, time, data, perf);

	if (report_type == INTER_REPORT) client.i_report.last_report_time += duration;
	else xil_printf("[%3d] sent %llu datagrams\n", client.client_id, client.cnt_datagrams);

}


static void reset_stats(void) {

	client.client_id++;

	/* Print connection statistics */
	print_udp_conn_stats();

	/* Save start time for final report */
	client.start_time = sys_now();
	client.total_bytes = 0;
	client.cnt_datagrams = 0;

	/* Initialize Interim report parameters */
	client.i_report.start_time = 0;
	client.i_report.total_bytes = 0;
	client.i_report.last_report_time = 0;

}

static int udp_packet_send(u8_t finished, uint8_t* array, int frame_counter, int data_amount) {

	int total_amount = data_amount + UDP_METADATA_SIZE;
	static int packet_id;
	int count;
	u8_t retries = MAX_SEND_RETRY;
	socklen_t len = sizeof(addr);

	int *payload = (int*)send_buf;
	if (finished == FINISH) packet_id = -1;
	*payload = htonl(packet_id);

	// Copy to send_array
	if(data_amount != 0) memcpy(&send_buf[UDP_METADATA_SIZE], &array[frame_counter * UDP_DATA_SIZE], data_amount * sizeof(char));

	/* always increment the id */
	packet_id++;

	while (retries) {
#if LWIP_UDP_OPT_BLOCK_TX_TILL_COMPLETE
		count = lwip_sendto_blocking(udp_socket, send_buf, total_amount, 0, (struct sockaddr *)&addr, len);
#else
		count = lwip_sendto(udp_socket, send_buf, total_amount, 0, (struct sockaddr *)&addr, len);
#endif
		if (count <= 0) {
			retries--;
			usleep(ERROR_SLEEP);
		} else {
			client.total_bytes += count;
			client.cnt_datagrams++;
			client.i_report.total_bytes += count;
			break;
		}
	}

	if (!retries) {
		/* Terminate this app */
		u64_t now = sys_now();
		u64_t diff_ms = now - client.start_time;
		xil_printf("Too many udp_send() retries, ");
		xil_printf("Terminating application\n");
		udp_conn_report(diff_ms, UDP_DONE_CLIENT);
		xil_printf("UDP test failed\n");
		return -1;
	}
	retries = MAX_SEND_RETRY;

#if !LWIP_UDP_OPT_BLOCK_TX_TILL_COMPLETE
#if defined (__aarch64__) && defined (XLWIP_CONFIG_INCLUDE_GEM)
		usleep(1);
#endif /* __aarch64__ */
#endif

	return 0;

}

int udp_connect_to_server() {

	err_t err;

	memset(&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(UDP_CONN_PORT);
	addr.sin_addr.s_addr = inet_addr(UDP_SERVER_IP_ADDRESS);

	// Create socket
	if ((udp_socket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		xil_printf("UDP client: Error creating udp_socket\n");
		return XST_FAILURE;
	}

	// Try to connect to that socket
	err = connect(udp_socket, (struct sockaddr *)&addr, sizeof(addr));
	if (err != ERR_OK) {
		xil_printf("UDP client: Error on connect: %d\n", err);
		close(udp_socket);
		return XST_FAILURE;
	}

	/* Wait for successful connections */
	usleep(10);

	reset_stats();

	return XST_SUCCESS;

}


void report() {

	if (REPORT_INTERVAL_TIME) {
		u64_t now = sys_now();
		if (REPORT_INTERVAL_TIME) {
			if (client.i_report.start_time) {
				u64_t diff_ms = now - client.i_report.start_time;
				if (diff_ms >= REPORT_INTERVAL_TIME) {
					udp_conn_report(diff_ms, INTER_REPORT);
					client.i_report.start_time = 0;
					client.i_report.total_bytes = 0;
				}
			} else {
				client.i_report.start_time = now;
			}
		}

	}

}

/* Transmit data on a udp session */
int udp_transfer_data_to_server(uint8_t *array, int size) {

	int frame_counter = 0;
	int amount_left = size;
	int amount_to_send;

	while(amount_left > 0) {

		if((amount_left / UDP_DATA_SIZE) == 0) {
			amount_to_send = amount_left;
			amount_left = 0;
		} else {
			amount_to_send = UDP_DATA_SIZE;
			amount_left -= UDP_DATA_SIZE;
		}

		report(); // For debug

		if(amount_left == 0) {

			udp_packet_send(FINISH, array, frame_counter, amount_to_send);

		} else {

			udp_packet_send(!FINISH, array, frame_counter, amount_to_send);

		}

		frame_counter++;

	}

	return XST_SUCCESS;

}
