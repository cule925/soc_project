#ifndef NETWORK_H
#define NETWORK_H

#include <stdint.h>

// Driver interface
int network_init();
int network_connect();
void network_udp_transfer(uint8_t* array, int size);

#endif
