#include "uart.h"
#include "xparameters.h"
#include "xuartps.h"

#include "../../param_config.h"

XUartPs Uart_Ps;

// Initialize driver
int uart_init() {

	int Status;
	XUartPs_Config *Uart_Ps_Config;

	Uart_Ps_Config = XUartPs_LookupConfig(XPAR_PS7_UART_1_DEVICE_ID);
	if(Uart_Ps_Config == NULL) return XST_FAILURE;

	Status = XUartPs_CfgInitialize(&Uart_Ps, Uart_Ps_Config, Uart_Ps_Config->BaseAddress);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	XUartPs_SetBaudRate(&Uart_Ps, UART_BAUD_RATE);

	return XST_SUCCESS;

}
