#ifndef UART_INIT_H
#define UART_INIT_H

// Driver interface
int uart_init();

#endif
