#ifndef IIC_CAMERA_INIT_H
#define IIC_CAMERA_INIT_H

#include <stdint.h>

// Camera configuration
#define IIC_SLAVE_ADDR		0x21
#define IIC_SCLK_RATE		400000

// Driver interface
int iic_camera_init();

// Get colors
void get_green(uint8_t* image_buffer, int image_buffer_size);
void get_red(uint8_t* image_buffer, int image_buffer_size);
void get_blue(uint8_t* image_buffer, int image_buffer_size);
void get_white(uint8_t* image_buffer, int image_buffer_size);
void get_black(uint8_t* image_buffer, int image_buffer_size);

#endif
