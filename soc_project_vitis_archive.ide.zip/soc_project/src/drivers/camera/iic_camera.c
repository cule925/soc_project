#include "iic_camera.h"
#include "xparameters.h"
#include "xiicps.h"

#include "camera_config.h"
#include "../../param_config.h"

XIicPs Iic_Ps;

void get_green(uint8_t* image_buffer, int image_buffer_size) {

	// Pure green: 00000111 11100000 => 0x07 0xE0
	for(int i = 0; i < image_buffer_size; i+=2) {

		// LSByte
		image_buffer[i] = 0xE0;

		// MSByte
		image_buffer[i + 1] = 0x07;

	}

}

void get_red(uint8_t* image_buffer, int image_buffer_size) {

	// Pure red: 11111000 00000000 => 0xF8 0x00
	for(int i = 0; i < image_buffer_size; i+=2) {

		// LSByte
		image_buffer[i] = 0x00;

		// MSByte
		image_buffer[i + 1] = 0xF8;

	}

}

void get_blue(uint8_t* image_buffer, int image_buffer_size) {

	// Pure blue: 00000000 00011111 => 0x00 0x1F
	for(int i = 0; i < image_buffer_size; i+=2) {

		// LSByte
		image_buffer[i] = 0x1F;

		// MSByte
		image_buffer[i + 1] = 0x00;

	}

}

void get_white(uint8_t* image_buffer, int image_buffer_size) {

	// Pure white: 11111111 11111111 => 0xFF 0xFF
	for(int i = 0; i < image_buffer_size; i+=2) {

		// LSByte
		image_buffer[i] = 0xFF;

		// MSByte
		image_buffer[i + 1] = 0xFF;

	}

}

void get_black(uint8_t* image_buffer, int image_buffer_size) {

	// Pure blue: 00000000 00000000 => 0x00 0x00
	for(int i = 0; i < image_buffer_size; i+=2) {

		// LSByte
		image_buffer[i] = 0x00;

		// MSByte
		image_buffer[i + 1] = 0x00;

	}

}

// Write to slave
int write_to_camera(uint8_t* buffer, int32_t size) {

	int Status;

	Status = XIicPs_MasterSendPolled(&Iic_Ps, buffer, size, IIC_SLAVE_ADDR);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	while(XIicPs_BusIsBusy(&Iic_Ps));

	return XST_SUCCESS;

}

// Read from slave
int read_from_camera(uint8_t* buffer, int32_t size) {

	int Status;

	Status = XIicPs_MasterRecvPolled(&Iic_Ps, buffer, size, IIC_SLAVE_ADDR);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	while(XIicPs_BusIsBusy(&Iic_Ps));

	return XST_SUCCESS;

}

int custom_reg_write() {

	int Status;
	unsigned char w_buf[2] = {0};

	// Use external clock (XDC)
	w_buf[0] = REG_CLKRC;
	w_buf[1] = CLK_EXT;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// Use VGA and RGB
	w_buf[0] = REG_COM7;
	w_buf[1] = COM7_FMT_VGA | COM7_RGB;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// Use RGB565
	w_buf[0] = REG_COM15;
	w_buf[1] = COM15_RGB565 | COM15_R00FF;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// Do not use RGB444
	w_buf[0] = REG_RGB444;
	w_buf[1] = 0x0;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// Flip the image diagonally
	w_buf[0] = REG_MVFP;
	w_buf[1] = MVFP_MIRROR | MVFP_FLIP;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	// Experimentally
	w_buf[0] = REG_COM13;
	w_buf[1] = COM13_GAMMA | COM13_UVSAT;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	w_buf[0] = REG_BLUE;
	w_buf[1] = 0x01;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	w_buf[0] = REG_RED;
	w_buf[1] = 0x40;
	Status = write_to_camera(w_buf, sizeof(w_buf));
	if(Status != XST_SUCCESS) return XST_FAILURE;

	return XST_SUCCESS;

}

// Configure camera (our I2C slave)
int camera_config() {

	int Status;
	unsigned char w_buf[2] = {0};

	// RGB565 VGA 640x480
	for(int i = 0; i < (sizeof(ov7670_default_regs) / sizeof(ov7670_default_regs[0])); i++) {

		w_buf[0] = ov7670_default_regs[i].reg_num;
		w_buf[1] = ov7670_default_regs[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}

	Status = custom_reg_write();
	if(Status != XST_SUCCESS) return XST_FAILURE;

	/*for(int i = 0; i < (sizeof(ov7670_fmt_rgb565) / sizeof(ov7670_fmt_rgb565[0])); i++) {

		w_buf[0] = ov7670_fmt_rgb565[i].reg_num;
		w_buf[1] = ov7670_fmt_rgb565[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}*/

	/*for(int i = 0; i < (sizeof(ov7670_image) / sizeof(ov7670_image[0])); i++) {

		w_buf[0] = ov7670_image[i].reg_num;
		w_buf[1] = ov7670_image[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}*/


	/*for(int i = 0; i < (sizeof(ov7670_test_bar) / sizeof(ov7670_test_bar[0])); i++) {

		w_buf[0] = ov7670_test_bar[i].reg_num;
		w_buf[1] = ov7670_test_bar[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}*/

	/*for(int i = 0; i < (sizeof(ov7670_test_shift) / sizeof(ov7670_test_shift[0])); i++) {

		w_buf[0] = ov7670_test_shift[i].reg_num;
		w_buf[1] = ov7670_test_shift[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}*/

	/*for(int i = 0; i < (sizeof(ov7670_test_FadeToGray) / sizeof(ov7670_test_FadeToGray[0])); i++) {

		w_buf[0] = ov7670_test_FadeToGray[i].reg_num;
		w_buf[1] = ov7670_test_FadeToGray[i].value;
		Status = write_to_camera(w_buf, sizeof(w_buf));
		if(Status != XST_SUCCESS) return XST_FAILURE;

	}*/

	return XST_SUCCESS;

}

// Initialize driver
int iic_camera_init() {

	int Status;
	XIicPs_Config *Iic_Ps_Config;

	Iic_Ps_Config = XIicPs_LookupConfig(XPAR_PS7_I2C_0_DEVICE_ID);
	if(Iic_Ps_Config == NULL) return XST_FAILURE;

	Status = XIicPs_CfgInitialize(&Iic_Ps, Iic_Ps_Config, Iic_Ps_Config->BaseAddress);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	Status = XIicPs_SelfTest(&Iic_Ps);
	if (Status != XST_SUCCESS) return XST_FAILURE;

	Status = XIicPs_SetSClk(&Iic_Ps, IIC_SCLK_RATE);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	Status = camera_config();
	if(Status != XST_SUCCESS) return XST_FAILURE;

	return XST_SUCCESS;

}
