#ifndef PARAM_CONFIG_H
#define PARAM_CONFIG_H

// UART CONFIGURATION
#define UART_BAUD_RATE		115200

// VDMA CONFIGURATION

// Frame buffer locations
// Changed DDR memory size from 1FF00000 to 0xEFFFFF in linker script
#define FRAME_BUFFER_1			0x10000000
#define FRAME_BUFFER_2			0x10200000
#define FRAME_BUFFER_3			0x10400000
#define FRAME_BUFFER_NUMBER		3

#define EXTENDED_SIZE			2
#define BYTES_PER_PIXEL		2

#define WIDTH				640
#define HEIGHT				480

#define FRAME_BUFFER_SIZE	(WIDTH * HEIGHT * (BYTES_PER_PIXEL + EXTENDED_SIZE))

// NETWORK CONFIGURATION
#define BOARD_IP_ADDRESS 			"10.0.0.11"
#define BOARD_IP_MASK 				"255.0.0.0"
#define BOARD_GW_ADDRESS 			"0.0.0.0"

// PC side
#define INTERIM_REPORT_INTERVAL 		5		// Seconds between periodic bandwidth reports

#define UDP_CONN_PORT 					5001
#define UDP_SERVER_IP_ADDRESS 			"10.0.0.10"
#define UDP_SEND_BUFSIZE 				1440	// UDP packet size
#define UDP_METADATA_SIZE 				4		// UDP packet id size (sizeof integer)
#define UDP_DATA_SIZE 					(UDP_SEND_BUFSIZE - UDP_METADATA_SIZE)

#define MAX_SEND_RETRY 10

#define ERROR_SLEEP 100							// Sleep in microseconds in case of UDP send errors

// Color saturation reduction
#define RED_SUB			0
#define GREEN_SUB		0
#define BLUE_SUB		16

#endif
