#include <stdio.h>
#include "xstatus.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "FreeRTOS.h"
#include "task.h"

#include "drivers/camera/iic_camera.h"
#include "drivers/gpio/gpio.h"
#include "drivers/uart/uart.h"
#include "drivers/vdma/vdma.h"
#include "drivers/network/network.h"

#include "param_config.h"

// Frame buffers
static uint8_t* frame_buffer[] = {
		(uint8_t*)FRAME_BUFFER_1,
		(uint8_t*)FRAME_BUFFER_2,
		(uint8_t*)FRAME_BUFFER_3
};

// Image check
uint8_t image_buffer[HEIGHT * WIDTH * BYTES_PER_PIXEL] = {0};

int frame_buffer_size = FRAME_BUFFER_SIZE * sizeof(uint8_t);
int image_buffer_size = HEIGHT * WIDTH * BYTES_PER_PIXEL * sizeof(uint8_t);
int quarter_image_buffer_size = HEIGHT * WIDTH * BYTES_PER_PIXEL * sizeof(uint8_t) / 4;

// Frames sent
int frame_count = 0;

// Initializastion stage
int init_stage = 0;

// Task handles
TaskHandle_t xHandle_Start_Routine;
TaskHandle_t xHandle_Switch_Reading_Routine;
TaskHandle_t xHandle_Button_Reading_Routine;
TaskHandle_t xHandle_Blink_Leds_Routine;

// Switch states
int sw0 = 0, sw1 = 0;

// Color substraction
uint8_t sub_red = RED_SUB, sub_green = GREEN_SUB, sub_blue = BLUE_SUB;

// Simple pause
void pause_ms(int pause) {

	vTaskDelay(pause / portTICK_PERIOD_MS);

}

// Initialize every peripheral and component
void init() {

	// Initialize UART
	if(uart_init() != XST_SUCCESS) {
		xil_printf("UART init failure!\n");
		while(1);
	}
	xil_printf("UART init success!\n");

	// Initialize Network
	if(network_init() != XST_SUCCESS) {
		xil_printf("Network init failure!\n");
		while(1);
	}
	xil_printf("Network init success!\n");

	// Initialize AXI GPIOs
	if(gpio_init() != XST_SUCCESS) {
		xil_printf("GPIO init failure!\n");
		while(1);
	}
	xil_printf("GPIO init success!\n");

	// Initialize IIC camera
	if(iic_camera_init() != XST_SUCCESS) {
		xil_printf("IIC CAMERA init failure!\n");
		while(1);
	}
	xil_printf("IIC CAMERA init success!\n");

	// Initialize VDMA
	if(vdma_init() != XST_SUCCESS) {
		xil_printf("VDMA init failure!\n");
		while(1);
	}
	xil_printf("VDMA init success!\n");

}

// Blink LED-s task
void blink_leds(void* pvParameters) {

	uint32_t led_init_stage[] = {
			LED_0,
			LED_1,
			LED_2,
			LED_3,
			RGB_0,
			RGB_1,
			RGB_0,
			RGB_1,
			RGB_2
	};

	// Wait for init stage to start
	while(init_stage == 0) pause_ms(500);

	int led = 0;
	while(1) {

		// DELETE
		xil_printf("Init stage: %d, led: %d\n", init_stage, led);

		led = init_stage - 1;
		if(led >= sizeof(led_init_stage)/sizeof(led_init_stage[0])) break;

		gpio_write(led_init_stage[led], 1);
		pause_ms(500);
		gpio_write(led_init_stage[led], 0);
		pause_ms(500);

	}

	vTaskDelete(NULL);

}

// GPIO check
void gpio_check() {

	uint32_t value;

	// Create seperate task for LED blinking on init mode
	xTaskCreate(blink_leds, "BLINK_LEDS", configMINIMAL_STACK_SIZE, (void*)&init_stage, 1, &xHandle_Blink_Leds_Routine);

	// LED CHECK
	xil_printf("4 LED check...\n");

	value = 1;
	for(int i = 0; i < 4; i++) {
		gpio_write(LED_0 + i, value);
		pause_ms(400);
	}

	value = 0;
	for(int i = 0; i < 4; i++) {
		gpio_write(LED_0 + i, value);
		pause_ms(400);
	}

	xil_printf("4 LED check completed!\n");

	// BTN CHECK
	init_stage++;
	xil_printf("Please press button BTND:\n");
	while(gpio_read(BTN_0) == 0) pause_ms(100);
	xil_printf("BTND pressed!\n");

	init_stage++;
	xil_printf("Please press button BTNR:\n");
	while(gpio_read(BTN_1) == 0) pause_ms(100);
	xil_printf("BTNR pressed!\n");

	init_stage++;
	xil_printf("Please press button BTNU:\n");
	while(gpio_read(BTN_2) == 0) pause_ms(100);
	xil_printf("BTNU pressed!\n");

	init_stage++;
	xil_printf("Please press button BTNL:\n");
	while(gpio_read(BTN_3) == 0) pause_ms(100);
	xil_printf("BTNL pressed!\n");

	// RGB CHECK
	xil_printf("RGB check...\n");

	value = 1;
	for(int i = 0; i < 3; i++) {
		gpio_write(RGB_0 + i, value);
		pause_ms(400);
	}

	value = 0;
	for(int i = 0; i < 3; i++) {
		gpio_write(RGB_0 + i, value);
		pause_ms(400);
	}

	xil_printf("RGB check completed!\n");

	// SW CHECK
	init_stage++;
	xil_printf("Please activate switch SW0:\n");
	while(gpio_read(SW_0) == 0) pause_ms(100);
	xil_printf("SW0 activated!\n");

	init_stage++;
	xil_printf("Please deactivate switch SW0:\n");
	while(gpio_read(SW_0) == 1) pause_ms(100);
	xil_printf("SW0 deactivated!\n");

	init_stage++;
	xil_printf("Please activate switch SW1:\n");
	while(gpio_read(SW_1) == 0) pause_ms(100);
	xil_printf("SW1 activated!\n");

	init_stage++;
	xil_printf("Please deactivate switch SW1:\n");
	while(gpio_read(SW_1) == 1) pause_ms(100);
	xil_printf("SW1 deactivated!\n");

	init_stage++;
	pause_ms(2000);
	init_stage++;

}

// Image check for the server, displays colors not from the camera but the Zedboard itself (hardcoded)
void image_check() {

	pause_ms(2000);

	xil_printf("Check red...\n");
	get_red(image_buffer, image_buffer_size);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(1800);

	xil_printf("Check green...\n");
	get_green(image_buffer, image_buffer_size);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(1800);

	xil_printf("Check blue...\n");
	get_blue(image_buffer, image_buffer_size);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(1800);

	xil_printf("Check white...\n");
	get_white(image_buffer, image_buffer_size);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(1800);

	xil_printf("Check black...\n");
	get_black(image_buffer, image_buffer_size);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(200);
	network_udp_transfer(image_buffer, image_buffer_size);
	pause_ms(1800);

}

// Read buttons, BTND - reset all components to defaults, BTNL - R component gain, BTNU - G component gain, BTNR - B component gain
void button_reading(void* pvParameters) {

	while(1) {

		// Reset to defaults
		if(gpio_read(BTN_0)) {

			sub_red = RED_SUB;
			sub_green = GREEN_SUB;
			sub_blue = BLUE_SUB;
			xil_printf("Registered button BTND\n");

		}

		// If blue button is pressed
		if(gpio_read(BTN_1)) {

			sub_blue += 4;
			if(sub_blue > 16) sub_blue = 0;
			xil_printf("Registered button BTNR\n");

		}

		// If green button is pressed
		if(gpio_read(BTN_2)) {

			sub_green += 4;
			if(sub_green > 16) sub_green = 0;
			xil_printf("Registered button BTNU\n");

		}

		// If red button is pressed
		if(gpio_read(BTN_3)) {

			sub_red += 4;
			if(sub_red > 16) sub_red = 0;
			xil_printf("Registered button BTNL\n");

		}

		pause_ms(500);

	}

}

// Read switches
void switch_reading(void* pvParameters) {

	while(1) {

		// Switching between color and gray
		sw0 = gpio_read(SW_0) ? 1 : 0;

		// Switching between normal 1x mode and 4x mode
		sw1 = gpio_read(SW_1) ? 1 : 0;
		pause_ms(500);

	}

}

// Display a regular 640 x 480 rgb565 image
void colored_image(uint32_t buffer_index) {

	uint8_t *start_ptr = &image_buffer[0];
	uint8_t *end_ptr = &image_buffer[image_buffer_size];

	uint8_t *frame_ptr = &frame_buffer[buffer_index][0];

	// Until the end of the framebuffer, one iteration, one pixel
	while(start_ptr < end_ptr) {

		// Extract RGB components
		uint8_t red = (*(frame_ptr++) >> 3) - RED_SUB;					// Scale to 5 bits: 000RRRRR
		uint8_t green = (*(frame_ptr++) >> 2) - GREEN_SUB;				// Scale to 6 bits: 00GGGGGG
		uint8_t blue = (*(frame_ptr++) >> 3) - BLUE_SUB;				// Scale to 5 bits: 000BBBBB

		// Ignore last component (padding)
		frame_ptr++;

		// Combine into RGB565 -> RRRRRGGGGGGBBBBB
		uint16_t pixel = (red << 11) | (green << 5) | blue;

		// LSByte
		*(start_ptr++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr++) = (uint8_t)(pixel >> 8);						// RRRRRGGG

	}

}

// Display a regular 640 x 480 rgb565 image
void colored_image_4x(uint32_t buffer_index) {

	uint8_t *start_ptr_0 = &image_buffer[0];
	uint8_t *start_ptr_1 = &image_buffer[WIDTH];
	uint8_t *start_ptr_2 = &image_buffer[2 * WIDTH * HEIGHT / 2];
	uint8_t *start_ptr_3 = &image_buffer[2 * WIDTH * HEIGHT / 2 + WIDTH];

	uint8_t *frame_ptr = &frame_buffer[buffer_index][0];
	uint8_t *frame_end_ptr = frame_ptr + frame_buffer_size;
	uint8_t *checkpoint_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);

	// Until the end of the framebuffer, one iteration, multiple pixels
	while(frame_ptr < frame_end_ptr) {

		// Row 0, 2, 4, 6, ...
		if(frame_ptr == checkpoint_ptr) {

			frame_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);
			checkpoint_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);

			start_ptr_0 += WIDTH;
			start_ptr_1 += WIDTH;
			start_ptr_2 += WIDTH;
			start_ptr_3 += WIDTH;

		}

		// Extract RGB components
		uint8_t red = *(frame_ptr++) >> 3;						// Scale to 5 bits: 000RRRRR
		uint8_t green = *(frame_ptr++) >> 2;					// Scale to 6 bits: 00GGGGGG
		uint8_t blue = *(frame_ptr++) >> 3;						// Scale to 5 bits: 000BBBBB

		// Try to correct gain
		red = (red > sub_red) ? (red - sub_red) : 0;
		green = (green > sub_green) ? (green - sub_green) : 0;
		blue = (blue > sub_blue) ? (blue - sub_blue) : 0;

		// Ignore last component (padding)
		frame_ptr++;

		// Combine into RGB565 -> RRRRRGGGGGGBBBBB
		uint16_t pixel = (red << 11) | (green << 5) | blue;

		// LSByte
		*(start_ptr_0++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_0++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_1++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_1++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_2++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_2++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_3++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_3++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// Ignore the next pixel
		frame_ptr+=4;

	}

}

// Display a 320 x 240 gray image 4 times
void gray_image(uint32_t buffer_index) {

	uint8_t *start_ptr = &image_buffer[0];
	uint8_t *end_ptr = &image_buffer[image_buffer_size];

	uint8_t *frame_ptr = &frame_buffer[buffer_index][0];

	while(start_ptr < end_ptr) {

		// Until the end of the framebuffer, one iteration, one pixel
		uint16_t red = ((*(frame_ptr++) >> 3)) - RED_SUB;				// Scale to 5 bits: 000RRRRR
		uint16_t green = ((*(frame_ptr++) >> 2)) - GREEN_SUB;			// Scale to 6 bits: 00GGGGGG
		uint16_t blue = (*(frame_ptr++) >> 3) - BLUE_SUB;				// Scale to 5 bits: 000BBBBB

		// Ignore last component (padding)
		frame_ptr++;

		uint16_t gray = (red + green + blue) / 3;

		// Combine into a gray image, take the average of the three
		uint16_t pixel = ((gray & 0x1F) << 11) | (((gray << 1) & 0x3F) << 5) | (gray & 0x1F);

		// LSByte
		*(start_ptr++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr++) = (uint8_t)(pixel >> 8);						// RRRRRGGG

	}

}

// Display a 320 x 240 gray image 4 times
void gray_image_4x(uint32_t buffer_index) {

	uint8_t *start_ptr_0 = &image_buffer[0];
	uint8_t *start_ptr_1 = &image_buffer[WIDTH];
	uint8_t *start_ptr_2 = &image_buffer[2 * WIDTH * HEIGHT / 2];
	uint8_t *start_ptr_3 = &image_buffer[2 * WIDTH * HEIGHT / 2 + WIDTH];

	uint8_t *frame_ptr = &frame_buffer[buffer_index][0];
	uint8_t *frame_end_ptr = frame_ptr + frame_buffer_size;
	uint8_t *checkpoint_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);

	// Until the end of the framebuffer, one iteration, multiple pixels
	while(frame_ptr < frame_end_ptr) {

		// Row 0, 2, 4, 6, ...
		if(frame_ptr == checkpoint_ptr) {

			frame_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);
			checkpoint_ptr = frame_ptr + WIDTH * (BYTES_PER_PIXEL + EXTENDED_SIZE);

			start_ptr_0 += WIDTH;
			start_ptr_1 += WIDTH;
			start_ptr_2 += WIDTH;
			start_ptr_3 += WIDTH;

		}

		// Extract RGB components from the pixel
		uint16_t red = (*(frame_ptr++) >> 3);					// Scale to 5 bits: 000RRRRR
		uint16_t green = (*(frame_ptr++) >> 2);					// Scale to 6 bits: 00GGGGGG
		uint16_t blue = (*(frame_ptr++) >> 3);					// Scale to 5 bits: 000BBBBB

		// Try to correct gain
		red = (red > sub_red) ? (red - sub_red) : 0;
		green = (green > sub_green) ? (green - sub_green) : 0;
		blue = (blue > sub_blue) ? (blue - sub_blue) : 0;


		// Ignore last component (padding)
		frame_ptr++;

		uint16_t gray = (red + green + blue) / 3;

		// Combine into a gray image, take the average of the three
		uint16_t pixel = ((gray & 0x1F) << 11) | (((gray << 1) & 0x3F) << 5) | (gray & 0x1F);

		// LSByte
		*(start_ptr_0++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_0++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_1++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_1++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_2++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_2++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// LSByte
		*(start_ptr_3++) = (uint8_t)pixel;							// GGGBBBBB

		// MSByte
		*(start_ptr_3++) = (uint8_t)(pixel >> 8);					// RRRRRGGG

		// Ignore the next pixel
		frame_ptr+=4;

	}


}


void start_image_transfer() {

	uint32_t buffer_index = 0;

	// Create tasks that will read button states
	xTaskCreate(switch_reading, "SWITCH_READING", configMINIMAL_STACK_SIZE, NULL, 1, &xHandle_Switch_Reading_Routine);
	xTaskCreate(button_reading, "BUTTON_READING", configMINIMAL_STACK_SIZE, NULL, 1, &xHandle_Button_Reading_Routine);

	while(1) {

		// Check if VDMA is writting in current buffer
		while(frame_buffer_is_busy(buffer_index) == XST_FAILURE) pause_ms(10);

		if(sw0 == 0) {
			if(sw1 == 0) colored_image(buffer_index);
			else colored_image_4x(buffer_index);
		} else {
			if(sw1 == 0) gray_image(buffer_index);
			else gray_image_4x(buffer_index);
		}

		// Begin transfering the frame
		network_udp_transfer(image_buffer, image_buffer_size);

		// Onto next buffer
		buffer_index = (buffer_index + 1) % FRAME_BUFFER_NUMBER;

	}

}

void start_routine(void* pvParameters) {

	// Initialize everything
	init();
	xil_printf("Initialization finished!\n");

	// Check AXI GPIOs
	gpio_check();
	xil_printf("GPIO check completed!\n");

	// Connect to network
	if(network_connect() < 0) {
		printf("Server connection failed! Halting...");
		while(1);
	}

	// Check camera, VDMA, and Ethernet
	image_check();

	// Start image sampling
	start_image_transfer();
	xil_printf("Stopped transfering\n");

}

int main() {

	xTaskCreate(start_routine, "START_ROUTINE", configMINIMAL_STACK_SIZE * 50, NULL, 3, &xHandle_Start_Routine);
	vTaskStartScheduler();

	while(1);

	return 0;

}
